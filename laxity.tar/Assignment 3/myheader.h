#ifndef __RTS__
#define __RTS__
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>
#include<math.h>

struct periodicTask{            		 //task definition
	int phase,p,D,id;           		 //following standard naming convention  
	float c;                 		//p=period,D=realtive deadline,c=execution time  
};

struct periodicJob{                         	//job definition
  	int arr_time,deadline,id;       		//arr_time=arrival time   
  	float wcet;
};

struct slack{
  float val;
  int id;
};

int readFile(FILE**);
struct periodicTask* readPeriodicJob(FILE*,int);
void checkFeas(struct periodicTask*,int);
int calcHyperPeriod(struct periodicTask*,int);
int calcFrameSize(struct periodicTask*,int,int);
void calculateSlack(struct periodicTask*,int,int);
void buildMinHeap(struct slack* ,int n);
int minHeapify(struct slack* ,int i,int heap_size);

#endif
